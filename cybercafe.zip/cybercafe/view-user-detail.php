<?php
session_start();
include('connection.php');

if (!isset($_SESSION['ccmsaid']) || strlen($_SESSION['ccmsaid']) == 0) {
    header('location:logout.php');
    exit;
} else {
    // Get the user ID from URL
    $cid = $_GET['upid'];

    // Check if the form is submitted
    if (isset($_POST['submit'])) {
            
        $status = $_POST['status'];
       // $fees = $_POST['fees']; 
       // Fetch InTime from database
       $result = mysqli_query($conn, "SELECT InTime FROM userdetails WHERE Users_id='$cid'");
       $data = mysqli_fetch_assoc($result);

       $inTime = strtotime($data['InTime']);
       $outTime = time(); // current server time

// Calculate session duration (in minutes)
$durationInMinutes = ($outTime - $inTime) / 60;

// Set rate (₹2 per minute)
$ratePerMinute = 2;

// Calculate and round up the total fees
$fees = ceil($durationInMinutes * $ratePerMinute);


        // Update query to update usermaster table
        date_default_timezone_set("Asia/Kolkata");
        $timeout=date("Y-m-d H:i:s");

        $query = mysqli_query($conn, "UPDATE userdetails SET Remarks='$Remarks', status='$status', Amount='$fees',TimeOUT=NOW() WHERE Users_id='$cid'");
        if ($query) {
    echo '<script>
    alert("Details updated");
    location.href = "view-user-detail.php?upid=' . $cid . '&print=true";
</script>';

        } else {
            $msg = "Something Went Wrong. Please try again";
        }
    }
}

    // Select query to fetch data from usermaster, userdetails, and computers tables
    $query = "SELECT u.EntryID as EID, u.UserName, u.UserAddress, u.MobileNumber, u.Email, 
                      COALESCE(c.ComputerName, 'N/A') AS ComputerName, 
                      COALESCE(c.ComputerLocation, 'N/A') AS ComputerLocation, 
                      COALESCE(c.IPAddress, 'N/A') AS IPAddress, 
                      u.IDProofNo, ud.InTime, 
                      COALESCE(ud.status, 'Not Updated') AS status, 
                      COALESCE(ud.Remarks, 'No Remarks') AS Remarks, 
                      ud.TimeOUT, ud.Amount
               FROM usermaster u
               LEFT JOIN userdetails ud ON u.Users_id = ud.Users_id
               LEFT JOIN computers c ON c.ComputerName = u.ComputerName
               WHERE u.Users_id = '$cid';";
 //echo $query;
 
    $ret = mysqli_query($conn, $query);

    if (!$ret) {
        echo "Error: " . mysqli_error($conn);
    }

?>

<!-- HTML form and other code continues below -->
 <!doctype html>
<html lang="en">

<head>
    <title>CCMS User Details</title>
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
<?php include_once('sidebar.php'); ?>

<div id="right-panel" class="right-panel">
    <?php include_once('header.php'); ?>

    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header"><strong>Detailed </strong><small> Info</small></div>
                        <p style="font-size:16px; color:red" align="center"><?php if (isset($msg)) { echo $msg; } ?> </p>
                        <div class="card-body card-block">
<?php
  while($row=mysqli_fetch_assoc($ret))
     {
      
    ?>
                        <table border="1" class="table table-bordered mg-b-0">
                                <tr>
                                    <th>Entry ID</th>
                                    <td><?php echo $row['EID'];?></td>
                                    <th>Full Name</th>
                                    <td><?php echo $row['UserName']; ?></td>
                                </tr>
                                <tr>
                                    <th>User Address</th>
                                    <td colspan="3"><?php echo htmlspecialchars($row['UserAddress'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <th>Mobile Number</th>
                                    <td><?php echo htmlspecialchars($row['MobileNumber'] ?? 'N/A'); ?></td>
                                    <th>Email</th>
                                    <td><?php echo htmlspecialchars($row['Email'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <th>Computer Name</th>
                                    <td><?php echo htmlspecialchars($row['ComputerName'] ?? 'N/A'); ?></td>
                                    <th>Computer Location</th>
                                    <td><?php echo htmlspecialchars($row['ComputerLocation'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <th>IP Address</th>
                                    <td><?php echo htmlspecialchars($row['IPAddress'] ?? 'N/A'); ?></td>
                                    <th>ID Proof</th>
                                    <td><?php echo htmlspecialchars($row['IDProofNo'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <th>In Time</th>
                                    <td><?php echo htmlspecialchars($row['InTime'] ?? 'N/A'); ?></td>
                                    <th>Status</th>
                                    <td>
                                        <?php
                                        $status = isset($row['status']) ? trim($row['status']) : '';
                                        if ($status==='') 
                                        {
                                            echo "Not Updated Yet";
                                        }
                                         elseif (strcasecmp($status, "Out") === 0)
                                          {
                                            echo "Check Out";
                                        } elseif ($status !== '') 
                                        {
                                            echo htmlspecialchars($status);    
                                        } else 
                                        {
                                            echo "not available";
                                        }
                                        //....
                                        ?>
                                    </td>
                                </tr>
                                                                     
                               
                           <?php
     

     ?>
                  
    

                            <form name="fsubmit" method="post" enctype="multipart/form-data">
                                
                                    <?php 
                                 ?>
                                        <tr><td colspan="2"><strong>Official/Updation of Fees</strong></td>
                                    </tr>
                                        
                                                                                <tr>
                                            <th>Status:</th>
                                            <td>
                                                <select name="status" class="form-control" required>
                                                    <option value="Out">Check Out</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <?php if (strcasecmp($row['status'], "Out") !== 0): ?>
                                            <tr align="center">
                                                <td colspan="2"><button type="submit" name="submit" class="btn btn-primary btn-sm">Update</button></td>
                                            </tr>
                                            <?php endif; ?>

                                    <?php  
                                    ?>
                                        <tr>
                                            
                                            <th>Out Time</th>
                                            <td><?php echo htmlspecialchars($row['TimeOUT'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Fees</th>
                                            <td>
                                                <?php echo htmlspecialchars($row['Amount'] ?? 'N/A'); ?></td>
                                        </tr>
                                    <?php }        
                                    
                                    
                                       ?>                      
            
                                
                                </table>
                                     </form>
     
 
                                <?php 
                                
                                ?>     
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .animated -->
    </div><!-- .content -->
</div><!-- /#right-panel -->

<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<?php if (isset($_GET['print']) && $_GET['print'] === 'true'): ?>
<script>
    window.addEventListener('load', function () {
        window.print();
        setTimeout(function () {
            window.location.href = 'manage-olduser.php';
        }, 1000);
    });
</script>
<?php endif; ?>

</body>
</html>

<?php  ?>