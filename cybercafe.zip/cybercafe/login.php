<?php
session_start();
include 'connection.php'; // Database connection file

// Generate CAPTCHA if not set or refresh is requested
if (!isset($_SESSION['captcha']) || isset($_GET['refresh_captcha'])) {
    $_SESSION['captcha'] = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), 0, 6);
    if (isset($_GET['refresh_captcha'])) {
        echo $_SESSION['captcha']; // Return new CAPTCHA for AJAX request
        exit;
    }
}
// Handle Login Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $captcha = trim($_POST['captcha']);

    // Check CAPTCHA
    if ($captcha !== $_SESSION['captcha']) {
        echo "<script>alert('Incorrect CAPTCHA. Please try again.'); window.location.href='login.php';</script>";
        exit;
    }

    // Hash the input password using MD5
    //$hashed_password = md5($password);

    // Verify user credentials
    $sql = "SELECT AdminID, UserName, Passwd FROM admin WHERE UserName = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Secure password verification
        if (password_verify($password,$row['Passwd'])) { 
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username;
            $_SESSION['ccmsaid']=$row['AdminID'];
            
    
            echo "<script>alert('Login Successful!'),
            location.href='dashboard.php';</script>";
            
        } else {
            echo "<script>alert('Invalid Username or Password!'),
             location.href='login.php';</script>";
        }
    } else {
        echo "<script>alert('Invalid Username or Password!'),location.href='login.php';</script>";
    }

    // Reset CAPTCHA after each login attempt
    $_SESSION['captcha'] = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), 0, 6);
}
?>

<!doctype html>
<html lang="en">
<head>
    <title>CCMS Admin Login</title>
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    
    <style>
        body {
            background-image: url('images/WhatsApp Image 2025-03-20 at 22.14.22_b987117f.jpg'); /* Change this to your background image */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .login-content {
            background-color: rgba(235, 240, 243, 0.88);
            padding: 22px;
            border-radius: 20px;
            box-shadow: 0px 0px 15px rgba(149, 147, 147, 0.52);
            width: 352px;
            margin: auto;
            margin-top:15px;
        }
        .heading-container{
            display:flex;
            justify-content:center;
            align-items:center;
            text-align:center;
        }
        .login-form input {
            background-color: #222;
            color: white;
            border: 1px solid #555;
            padding: 8px;
            border-radius: 5px;
            width: 100%;
        }
        .login-form input::placeholder {
            color: #bbb;
        }
        .password-container {
            position: relative;
        }
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 70%;
            transform: translateY(-50%);
            cursor: pointer;
            color: lightblue;
        }
        .btn-success {
            background-color:rgb(92, 42, 209);
            border: none;
            padding: 8px;
            width: 100%;
            font-size: 14px;
            border-radius: 5px;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .forgot-password {
            color: blue;
            text-align: right;
            display: block;
            font-size: 12px;
            margin-top: 5px;
        }
        .forgot-password:hover {
            text-decoration: underline;
            color: darkred;
        }
    </style>
</head>
<body>
    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                    <div class="heading-container">
                        <h3 style="color: white">Cyber Cafe Management System</h3>
                        <hr color="red"/>
                    </div>
                </div>
                <div class="login-form">
                    <form action="login.php" method="post" autocomplete="off">
                        <div class="form-group">
                            <label>Enter Username</label>
                            <input type="text" class="form-control" placeholder="User Name" required name="username" autocomplete="off">
                        </div>
                        <div class="form-group password-container">
                            <label>Enter Password</label>
                            <input type="password" class="form-control" placeholder="Password" required name="password" id="password" autocomplete="new-password">
                            <i class="fa fa-eye toggle-password" onclick="togglePassword()"></i>
                        </div>
                        <a href="forgotpassword.php" class="forgot-password">Forgot Password?</a>

                        <!-- CAPTCHA -->
                        <div class="form-group">
                            <label>Captcha</label>
                            <div id="captcha-text" style="background: black; color: white; font-size: 20px; padding: 8px; text-align: center; font-weight: bold;">
                                <?= $_SESSION['captcha']; ?>
                            </div>
                            <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="refreshCaptcha()">Refresh Captcha</button>
                            <input type="text" class="form-control mt-2" placeholder="Enter Captcha" required name="captcha">
                        </div>

                        <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30" name="login">Sign in</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById("password");
            var icon = document.querySelector(".toggle-password");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                icon.classList.remove("fa-eye");
                icon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                icon.classList.remove("fa-eye-slash");
                icon.classList.add("fa-eye");
            }
        }

        function refreshCaptcha() {
            fetch("captcha.php") // Request new captcha from the same PHP file
            .then(response => response.text())
            .then(data => {
                document.getElementById("captcha-text").innerHTML = data;
            })
            .catch(error => alert("Failed to refresh CAPTCHA."));
        }
    </script>
</body>
</html>