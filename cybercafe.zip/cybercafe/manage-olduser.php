<?php
session_start();
include('connection.php');

if (strlen($_SESSION['ccmsaid']) == 0) {
    header('location:logout.php');
} else {
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <title>CCMS New Users</title>
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include_once('sidebar.php'); ?>
<div id="right-panel" class="right-panel">
    <?php include_once('header.php'); ?>
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>All Users</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li class="active">All Users</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Users Details</strong>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>S.NO</th>
                                        <th>EntryID</th>
                                        <th>Full Name</th>
                                        <th>In Time</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = "
                                        SELECT u.Users_id, u.EntryID, u.UserName, ud.InTime
                                        FROM usermaster u
                                        LEFT JOIN userdetails ud ON u.Users_id = ud.Users_id
                                        where ud.status='out'
                                    ";
                                    $ret = mysqli_query($conn, $query);
                                    $cnt = 1;
                                    while ($row = mysqli_fetch_assoc($ret)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $cnt; ?></td>
                                            <td><?php echo !empty($row['EntryID']) ? $row['EntryID'] : 'N/A'; ?></td>
                                            <td><?php echo !empty($row['UserName']) ? $row['UserName'] : 'N/A'; ?></td>
                                            <td><?php echo !empty($row['InTime']) ? $row['InTime'] : 'N/A'; ?></td>
                                            <td>
                                                <a href="view-user-detail.php?upid=<?php echo $row['Users_id']; ?>" class="btn btn-primary btn-sm">View</a>
                                            </td>
                                        </tr>
                                        <?php
                                        $cnt++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
<?php } ?>