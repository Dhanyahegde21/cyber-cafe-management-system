<?php
session_start();

include('connection.php');

if (!isset($_SESSION['ccmsaid'])) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {

        $ccmsaid = $_SESSION['ccmsaid'];
        $compname = $_POST['compname'];
        $comploc = $_POST['comploc'];
        $idadd = $_POST['idadd'];
        $availability = $_POST['availability'];

        // New fields
        $keyboard = $_POST['keyboard'];
        $mouse = $_POST['mouse'];
        $monitor = $_POST['monitor'];
        $cpu = $_POST['cpu'];
        $scanner = $_POST['scanner'];
        $printer = $_POST['printer'];
        
        // FIRST INSERT: Save into computers table
        $query1 = mysqli_query($conn, "INSERT INTO computers(ComputerName, ComputerLocation, IPAddress, IsAvailable) 
        VALUES ('$compname', '$comploc', '$idadd', '$availability')");

        // Get the last inserted ComputerID
        $computerID = mysqli_insert_id($conn);

        // SECOND INSERT: Save into computerdetails table
        $query2 = mysqli_query($conn, "INSERT INTO computerdetails(ComputerID, Keyboard, Mouse, Monitor, CPU, Scanner, Printer) 
        VALUES ('$computerID', '$keyboard', '$mouse', '$monitor', '$cpu', '$scanner', '$printer')");

        if ($query1 && $query2) {
            echo '<script>alert("Computer Detail has been added successfully.")</script>';
            echo "<script>window.location.href ='add-computer.php'</script>";
        } else {
            echo '<script>alert("Something Went Wrong. Please try again")</script>';
        }
    }
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <title>CCMS Add Computers</title>

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>

    <?php include_once('sidebar.php');?>

    <div id="right-panel" class="right-panel">

        <?php include_once('header.php');?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Computer Details</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="dashboard.php">Dashboard</a></li>
                            <li><a href="add-computer.php">Computer Details</a></li>
                            <li class="active">Add</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Computer</strong><small> Details</small></div>
                            <form name="computer" method="post" action="">
                                <div class="card-body card-block">

                                    <div class="form-group">
                                        <label for="compname" class="form-control-label">Computer ID</label>
                                        <input type="text" name="compname" value="" class="form-control" id="compname" required="true">
                                    </div>

                                    <div class="form-group">
                                        <label for="comploc" class="form-control-label">Computer Location</label>
                                        <input type="text" name="comploc" value="" id="comploc" class="form-control" required="true">
                                    </div>

                                    <div class="form-group">
                                        <label for="idadd" class="form-control-label">IP Address</label>
                                        <input type="text" name="idadd" id="idadd" value="" class="form-control" required="true">
                                    </div>

                                    <div class="form-group">
                                        <label class="form-control-label">Computer Availability</label><br>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="availability" id="available" value="1" required="true">
                                            <label class="form-check-label" for="available">Available</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="availability" id="notavailable" value="0" required="true">
                                            <label class="form-check-label" for="notavailable">Not Available</label>
                                        </div>
                                    </div>

                                    <hr>

                                    <h5><strong>Hardware Details</strong></h5>
                                    <!-- Hardware Details -->
                                     <div class="card p-4 mb-4 shadow-sm">
                                        <h4 class="mb-4">Hardware Details</h4>
                                        <div class="row">
        <!-- Keyboard -->
        <div class="col-md-6 mb-3">
            <label class="form-label">Keyboard Working?</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="keyboard" id="keyboardYes" value="1" required>
                <label class="form-check-label" for="keyboardYes">Working</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="keyboard" id="keyboardNo" value="0" required>
                <label class="form-check-label" for="keyboardNo">Not Working</label>
            </div>
        </div>

        <!-- Mouse -->
        <div class="col-md-6 mb-3">
            <label class="form-label">Mouse Working?</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="mouse" id="mouseYes" value="1" required>
                <label class="form-check-label" for="mouseYes">Working</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="mouse" id="mouseNo" value="0" required>
                <label class="form-check-label" for="mouseNo">Not Working</label>
            </div>
        </div>

        <!-- Monitor -->
        <div class="col-md-6 mb-3">
            <label class="form-label">Monitor Working?</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="monitor" id="monitorYes" value="1" required>
                <label class="form-check-label" for="monitorYes">Working</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="monitor" id="monitorNo" value="0" required>
                <label class="form-check-label" for="monitorNo">Not Working</label>
            </div>
        </div>

        <!-- CPU -->
        <div class="col-md-6 mb-3">
            <label class="form-label">CPU Working?</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="cpu" id="cpuYes" value="1" required>
                <label class="form-check-label" for="cpuYes">Working</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="cpu" id="cpuNo" value="0" required>
                <label class="form-check-label" for="cpuNo">Not Working</label>
            </div>
        </div>

        <!-- Scanner -->
        <div class="col-md-6 mb-3">
            <label class="form-label">Scanner Working?</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="scanner" id="scannerYes" value="1" required>
                <label class="form-check-label" for="scannerYes">Working</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="scanner" id="scannerNo" value="0" required>
                <label class="form-check-label" for="scannerNo">Not Working</label>
            </div>
        </div>

        <!-- Printer -->
        <div class="col-md-6 mb-3">
            <label class="form-label">Printer Working?</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="printer" id="printerYes" value="1" required>
                <label class="form-check-label" for="printerYes">Working</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="printer" id="printerNo" value="0" required>
                <label class="form-check-label" for="printerNo">Not Working</label>
            </div>
        </div>

    </div>
</div>

                                              </div>

                                <div class="card-footer">
                                    <p style="text-align: center;">
                                        <button type="submit" class="btn btn-primary btn-sm" name="submit" id="submit">
                                            <i class="fa fa-dot-circle-o"></i> Add
                                        </button>
                                    </p>
                                </div>

                            </form>
                        </div>
                    </div>
                </div> <!-- .row -->

            </div> <!-- .animated -->
        </div> <!-- .content -->

    </div><!-- /#right-panel -->

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>

<?php } ?>