<?php
session_start();
//generate a new captcha
$_SESSION['captcha']=substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"),0,6);
//return the new CAPTCHA text for AJAX
echo $_SESSION['captcha'];
?>