<html>
    <?php
    $conn=mysqli_connect("localhost","root","");
    if(!$conn)
    die("Err:Connection failed:".mysqli_connect_error());
else
{
    $strname='cybercafe_db';
    $db=mysqli_select_db($conn,$strname);
   // echo "<h2> $strname mysql database Connected successfully<hr/></h2>";
}
?>
</html>