<?php
session_start();

include('connection.php');

if (strlen($_SESSION['ccmsaid']) == 0) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        $cmsaid = $_SESSION['ccmsaid'];
        $username = $_POST['username'];
        $uadd = $_POST['uadd'];
        $mobilenumber = $_POST['mobilenumber'];
        $email = $_POST['email'];
        $computername = $_POST['computername'];
        $idprooftype = $_POST['idprooftype'];
        $idproofno = $_POST['idproofno'];
        $entryid = mt_rand(100000000, 999999999);
        
        // Set current timestamp for InTime
        $inTime = date('Y-m-d H:i:s'); // Current timestamp
        
        // Set TimeOut as NULL initially
        $timeOut = NULL; // You can also use '0000-00-00 00:00:00' if you prefer
        
        // Step 1: Insert user into usermaster table
        $sql = "INSERT INTO usermaster(EntryID, UserName, UserAddress, MobileNumber, Email, ComputerName, IDProofType, IDProofNo) 
                VALUES ('$entryid', '$username', '$uadd', '$mobilenumber', '$email', '$computername', '$idprooftype', '$idproofno')";
        $query = mysqli_query($conn, $sql);

        if ($query) {
            // Step 2: Insert InTime and TimeOut into userdetails table
            $user_id = mysqli_insert_id($conn); // Get the ID of the newly inserted user
            $userdetails_query = "INSERT INTO userdetails (Users_id, InTime, TimeOut,status) VALUES ('$user_id', '$inTime', '$timeOut','In')";
            $details_query = mysqli_query($conn, $userdetails_query);
            
            if ($details_query) {
                echo '<script>alert("User Detail has been added.")</script>';
                echo "<script>window.location.href ='add-users.php'</script>";
            } else {
                echo '<script>alert("Something Went Wrong. InTime and TimeOut could not be set.")</script>';
            }
        } else {
            echo '<script>alert("Something Went Wrong. Please try again.")</script>';
        }
    }
?>

<!doctype html>
<html class="no-js" lang="en">
<head>
    <title>CCMS User Details</title>
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body>
<?php include_once('sidebar.php'); ?>
<div id="right-panel" class="right-panel">
    <?php include_once('header.php'); ?>
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title"><h1>User Detail</h1></div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="add-users.php">User Detail</a></li>
                        <li class="active">Add</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header"><strong>User</strong><small> Details</small></div>
                        <form name="userform" method="post" action="">
                            <div class="card-body card-block">
                                <div class="form-group">
                                    <label class="form-control-label">User Name</label>
                                    <input type="text" name="username" class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-control-label">User Address</label>
                                    <textarea name="uadd" class="form-control" required></textarea>
                                </div>

                                <div class="form-group">
                                    <label class="form-control-label">Mobile Number</label>
                                    <input type="text" name="mobilenumber" class="form-control" maxlength="10" pattern="[0-9]+" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-control-label">Email</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-control-label">Computer Name</label>
                                    <select name="computername" class="form-control" required>
                                        <option value="">Select Computer</option>
                                        <?php
                                        //$comp_query = mysqli_query($conn, "SELECT ComputerName FROM computers");
                                        $comp_query = mysqli_query($conn, "
                                        SELECT ComputerName FROM computers 
                                        WHERE ComputerName NOT IN (
                                        SELECT u.ComputerName
                                        FROM usermaster u
                                        JOIN userdetails ud ON u.Users_id = ud.Users_id
                                        WHERE ud.status = 'In')");
                                        while ($row = mysqli_fetch_assoc($comp_query)) {
                                            echo '<option value="' . $row['ComputerName'] . '">' . $row['ComputerName'] . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="form-control-label">ID Proof Type</label>
                                    <select name="idprooftype" class="form-control" required>
                                        <option value="">Select</option>
                                        <option value="Aadhar">Aadhar</option>
                                        <option value="PAN">PAN</option>
                                        <option value="Voter ID">Voter ID</option>
                                        <option value="Driving License">Driving License</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="form-control-label">ID Proof Number</label>
                                    <input type="text" name="idproofno" class="form-control" required>
                                </div>
                            </div>

                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                    <i class="fa fa-dot-circle-o"></i> Add
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
<?php } ?>