<?php
echo md5("Test@123");
?>