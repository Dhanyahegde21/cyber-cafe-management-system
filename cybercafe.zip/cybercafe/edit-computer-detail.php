<?php
session_start();
error_reporting(0);
include('connection.php');

if (strlen($_SESSION['ccmsaid'] == 0)) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        $eid = $_GET['editid'];
        $compname = $_POST['compname'];
        $comploc = $_POST['comploc'];
        $idadd = $_POST['idadd'];
        $isavailable = $_POST['isavailable'];

        $query = mysqli_query($conn, "UPDATE computers SET ComputerName='$compname', ComputerLocation='$comploc', IPAddress='$idadd', IsAvailable='$isavailable' WHERE ComputerID='$eid'");

        if ($query) {
            $msg = "Computer Detail has been updated.";
        } else {
            $msg = "Something Went Wrong. Please try again";
        }
    }
?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <title>CCMS Update Computer</title>
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet'>
</head>

<body>
    <?php include_once('sidebar.php'); ?>
    <div id="right-panel" class="right-panel">
        <?php include_once('header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Update Computer Detail</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Computer</strong> <small>Detail</small></div>
                            <form method="post" action="">
                                <p style="font-size:16px; color:red" align="center">
                                    <?php if ($msg) echo $msg; ?>
                                </p>
                                <div class="card-body card-block">
                                    <?php
                                    $cid = $_GET['editid'];
                                    $ret = mysqli_query($conn, "SELECT * FROM computers WHERE ComputerID='$cid'");
                                    while ($row = mysqli_fetch_array($ret)) {
                                    ?>
                                        <div class="form-group">
                                            <label class="form-control-label">Computer Name</label>
                                            <input type="text" name="compname" value="<?php echo $row['ComputerName']; ?>" class="form-control" required>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-control-label">Computer Location</label>
                                            <input type="text" name="comploc" value="<?php echo $row['ComputerLocation']; ?>" class="form-control" required>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-control-label">IP Address</label>
                                            <input type="text" name="idadd" value="<?php echo $row['IPAddress']; ?>" class="form-control" required>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-control-label">Is Available</label>
                                            <select name="isavailable" class="form-control" required>
                                                <option value="">--Select--</option>
                                                <option value="Yes" <?php if ($row['IsAvailable'] == 'Yes') echo 'selected'; ?>>Yes</option>
                                                <option value="No" <?php if ($row['IsAvailable'] == 'No') echo 'selected'; ?>>No</option>
                                            </select>
                                        </div>
                                    <?php } ?>
                                    <div class="card-footer text-center">
                                        <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                            <i class="fa fa-dot-circle-o"></i> Update
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>
<?php } ?>