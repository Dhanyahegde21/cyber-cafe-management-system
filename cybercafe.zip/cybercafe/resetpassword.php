<?php
session_start();
include('connection.php');

$msg = '';

if (!isset($_SESSION['email'])) {
    header("Location: forgotpassword.php");
    exit();
}

if (isset($_POST['submit'])) {
    $new_password = trim($_POST['newpassword']);
    $confirm_pw = trim($_POST['confirmpassword']);

    if ($new_password !== $confirm_pw) {
        $msg = "Passwords do not match.";
    } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&]).{6,}$/', $new_password)) {
        $msg = "Password must be at least 6 characters long and include uppercase, lowercase, number, and symbol.";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $email = $_SESSION['email'];
        $query = mysqli_query($conn, "UPDATE admin SET passwd='$hashed_password' WHERE Email='$email'");

        if ($query) {
            session_destroy();
            header("Location: login.php?reset=success");
            exit();
        } else {
            $msg = "Something went wrong. Please try again.";
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <title>Reset Password - CCMS</title>
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet'>

    <style>
        body {
            background-image: url('images/bg.jpg');
            background-size: cover;
            background-position: center;
            font-family: 'Open Sans', sans-serif;
        }
        .login-content {
            margin: 80px auto;
            max-width: 500px;
            background: rgba(0, 0, 0, 0.6);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px #000;
            color: white;
        }
        .login-logo h3 {
            font-size: 26px;
            color: white;
            margin-bottom: 10px;
            text-align: center;
        }
        .form-group label {
            font-weight: bold;
            color: #ddd;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-success {
            width: 100%;
            padding: 10px;
            font-size: 16px;
        }
        p.error-msg {
            color: #ff6666;
            font-weight: bold;
            text-align: center;
        }
        .toggle-password {
            cursor: pointer;
            position: absolute;
            right: 15px;
            top: 38px;
            color: #ccc;
        }
        .position-relative {
            position: relative;
        }
    </style>

    <script>
        function checkpass() {
            var newpass = document.resetpassword.newpassword.value.trim();
            var confirmpass = document.resetpassword.confirmpassword.value.trim();
            var pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&]).{6,}$/;

            if (newpass !== confirmpass) {
                alert('New Password and Confirm Password do not match');
                return false;
            } else if (!pattern.test(newpass)) {
                alert('Password must be at least 6 characters long and include uppercase, lowercase, number, and symbol.');
                return false;
            }
            return true;
        }

        function togglePassword(id, icon) {
            const input = document.getElementById(id);
            const iconEl = document.getElementById(icon);
            if (input.type === "password") {
                input.type = "text";
                iconEl.classList.remove("fa-eye");
                iconEl.classList.add("fa-eye-slash");
            } else {
                input.type = "password";
                iconEl.classList.remove("fa-eye-slash");
                iconEl.classList.add("fa-eye");
            }
        }
    </script>
</head>

<body class="bg-dark">
    <div class="container">
        <div class="login-content">
            <div class="login-logo">
                <h3>Cyber Cafe Management System</h3>
                <hr color="red" />
            </div>
            <div class="login-form">
                <form name="resetpassword" method="post" onsubmit="return checkpass();">
                    <p class="error-msg"><?php echo $msg; ?></p>

                    <div class="form-group position-relative">
                        <label>New Password</label>
                        <input type="password" class="form-control" name="newpassword" id="newpassword" required>
                        <span class="fa fa-eye toggle-password" id="toggleNew" onclick="togglePassword('newpassword','toggleNew')"></span>
                    </div>

                    <div class="form-group position-relative">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control" name="confirmpassword" id="confirmpassword" required>
                        <span class="fa fa-eye toggle-password" id="toggleConfirm" onclick="togglePassword('confirmpassword','toggleConfirm')"></span>
                    </div>

                    <button type="submit" class="btn btn-success" name="submit">Reset Password</button>
                </form>
            </div>
        </div>
    </div>

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
