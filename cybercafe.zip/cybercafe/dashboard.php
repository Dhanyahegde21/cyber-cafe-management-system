<?php 
session_start();
include('connection.php'); // Ensure database connection is included

if (!isset($_SESSION['ccmsaid'])) {
    header('Location: login.php'); // Redirect if session is not set
    exit();
}
?>

<!doctype html>
<html class="no-js" lang="en">
<head>
    <title>CCMS Admin Dashboard</title>
    
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <!--Custom Inline Css-->
    <style>
        /* Adjust sidebar logo position */
        .sidebar .sidebar-logo img {
            display:block;
            margin:auto;
            margin-top:50px !important; /* Adjust value as needed */
        }
        
        /* Additional styles for dashboard layout */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .dashboard-container {
            padding: 20px;
        }

        .dashboard-card {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>

    <?php include_once('sidebar.php'); ?>

    <div id="right-panel" class="right-panel">
        <?php include_once('header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">

            <!-- Total Users -->
            <a href="view-allusers.php" target="_blank">
                <div class="col-sm-6 col-lg-6">
                    <div class="card text-white bg-flat-color-4">
                        <div class="card-body pb-0">
                            <?php 
                            $query = mysqli_query($conn, "SELECT * FROM userdetails");
                            $usercounts = mysqli_num_rows($query);
                            ?>
                            <h3 class="mb-0">
                                <span class="count"><?php echo $usercounts; ?></span>
                            </h3>
                            <p class="text-light">Total Number of Users</p>
                        </div>
                    </div>
                </div>
            </a>

            <!-- Total Computers -->
            <a href="manage-computer.php" target="_blank">
                <div class="col-sm-6 col-lg-6">
                    <div class="card text-white bg-flat-color-2">
                        <div class="card-body pb-0">
                            <?php 
                            $query1 = mysqli_query($conn, "SELECT * FROM computers");
                            $totalcomp = mysqli_num_rows($query1);
                            ?>
                            <h3 class="mb-0">
                                <span class="count"><?php echo $totalcomp; ?></span>
                            </h3>
                            <p class="text-light">Total Computers</p>
                        </div>
                    </div>
                </div>
            </a>

            <!-- Total New Users -->
            <a href="manage-newusers.php" target="_blank">
                <div class="col-sm-6 col-lg-6">
                    <div class="card text-white bg-flat-color-3">
                        <div class="card-body pb-0">
                            <?php 
                            $query = mysqli_query($conn, "SELECT * FROM userdetails WHERE Status IS NULL OR Status=''");
                            $newusers = mysqli_num_rows($query);
                            ?>
                            <h3 class="mb-0">
                                <span class="count"><?php echo $newusers; ?></span>
                            </h3>
                            <p class="text-light">Total New Users (Still in Cafe)</p>
                        </div>
                    </div>
                </div>
            </a>

            <!-- Old Users (Out from Cafe) -->
            <a href="manage-olduser.php" target="_blank">
                <div class="col-sm-6 col-lg-6">
                    <div class="card text-white bg-flat-color-5">
                        <div class="card-body pb-0">
                            <?php 
                            $query = mysqli_query($conn, "SELECT * FROM userdetails WHERE Status='Out'");
                            $outusers = mysqli_num_rows($query);
                            ?>
                            <h3 class="mb-0">
                                <span class="count"><?php echo $outusers; ?></span>
                            </h3>
                            <p class="text-light">Old Users (Out from Cafe)</p>
                        </div>
                    </div>
                </div>
            </a>

        </div> <!-- .content -->
    </div><!-- /#right-panel -->

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>