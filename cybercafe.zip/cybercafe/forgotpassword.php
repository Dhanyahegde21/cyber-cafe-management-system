<?php
session_start();
include('connection.php');
$msg='';

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $hint_answer = $_POST['hint_answer'];  // Collect hint answer from the form

    // Fetch hint question and answer from the database
    $query = mysqli_query($conn, "SELECT AdminID, HintQuestion, HintAnswer FROM admin WHERE Email='$email'");
    $ret = mysqli_fetch_array($query);

    if ($ret > 0) {
        // Check if the answer matches the stored hint answer
        if (strtolower($hint_answer) === strtolower($ret['HintAnswer'])) {
            // Redirect to reset password page
            $_SESSION['email'] = $email;
            header("Location: resetpassword.php");
            exit();
        } else {
            $msg = "Incorrect hint answer. Please try again.";
        }
    } else {
        $msg = "Invalid email address. Please try again.";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <title>CCMS Forgot Password</title>
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
        body {
            background-size: cover;
            background-position: center;
            font-family: 'Open Sans', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url('images/WhatsApp Image 2025-03-20 at 22.14.22_b987117f.jpg');
        }
        .login-content {
            max-width: 450px;
            background: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        .login-logo h3 {
            font-size: 24px;
            color: black;
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #333;
            text-align: left;
        }
        .form-control {
            width: 100%;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid #ccc;
            padding: 10px;
            font-size: 14px;
            border-radius: 5px;
        }
        .btn-success {
            background: #28a745;
            border: none;
            padding: 10px;
            font-size: 16px;
            width: 100%;
            border-radius: 5px;
            color: white;
            cursor: pointer;
        }
        .btn-success:hover {
            background: #218838;
        }
        .checkbox {
            text-align: left;
            margin-top: 10px;
        }
        .checkbox a {
            color: #17a2b8;
            text-decoration: none;
        }
        .checkbox a:hover {
            color: #138496;
            text-decoration: underline;
        }
        p {
            text-align: center;
            font-size: 14px;
            color: red;
        }
    </style>
</head>
<body>
    <div class="login-content">
        <div class="login-logo">
            <h3>Forgot your password!</h3>
        </div>
        <div class="login-form">
            <form action="" method="post">
                <p><?php if ($msg) { echo $msg; } ?></p>
                <div class="form-group">
                    <label>Enter email address</label>
                    <input type="email" class="form-control" placeholder="Email" required name="email">
                </div>
                <div class="form-group">
                    <label>Hint Question: What is your pet's name?</label>
                    <input type="text" class="form-control" placeholder="Answer" required name="hint_answer">
                </div>
                <div class="checkbox">
                    <label>
                        <a href="login.php">signin</a>
                    </label>
                </div>
                <button type="submit" class="btn btn-success" name="submit">Submit</button>
            </form>
        </div>
    </div>

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>