-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 12, 2025 at 12:44 PM
-- Server version: 9.1.0
-- PHP Version: 8.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cybercafe_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `AdminID` int NOT NULL AUTO_INCREMENT,
  `AdminName` varchar(100) NOT NULL,
  `UserName` varchar(120) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Passwd` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `MobileNumber` bigint NOT NULL,
  `AdminRegDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`AdminID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`AdminID`, `AdminName`, `UserName`, `Email`, `Passwd`, `MobileNumber`, `AdminRegDate`) VALUES
(1, 'admin', 'admin', 'ddhanya@gmail.com', 'f925916e2754e5e03f75dd58a5733251', 636205534, '2025-03-25 16:55:16');

-- --------------------------------------------------------

--
-- Table structure for table `computerdetails`
--

DROP TABLE IF EXISTS `computerdetails`;
CREATE TABLE IF NOT EXISTS `computerdetails` (
  `SRNO` int NOT NULL AUTO_INCREMENT,
  `ComputerID` int NOT NULL,
  `Keyboard` tinyint(1) NOT NULL,
  `Mouse` tinyint(1) NOT NULL,
  `Monitor` tinyint(1) NOT NULL,
  `CPU` tinyint(1) NOT NULL,
  `Scanner` tinyint(1) NOT NULL,
  `Printer` tinyint(1) NOT NULL,
  PRIMARY KEY (`SRNO`),
  KEY `IDXCompID` (`ComputerID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `computerdetails`
--

INSERT INTO `computerdetails` (`SRNO`, `ComputerID`, `Keyboard`, `Mouse`, `Monitor`, `CPU`, `Scanner`, `Printer`) VALUES
(5, 6, 1, 1, 1, 1, 1, 0),
(7, 9, 1, 1, 1, 0, 1, 1),
(8, 10, 1, 1, 0, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `computers`
--

DROP TABLE IF EXISTS `computers`;
CREATE TABLE IF NOT EXISTS `computers` (
  `ComputerID` int NOT NULL AUTO_INCREMENT,
  `ComputerName` varchar(100) DEFAULT NULL,
  `ComputerLocation` varchar(255) DEFAULT NULL,
  `IPAddress` varchar(45) DEFAULT NULL,
  `IsAvailable` tinyint(1) NOT NULL,
  PRIMARY KEY (`ComputerID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `computers`
--

INSERT INTO `computers` (`ComputerID`, `ComputerName`, `ComputerLocation`, `IPAddress`, `IsAvailable`) VALUES
(6, 'Asus', 'cabin1', '7428.4', 1),
(7, 'HP', 'cabin102', '127.0.0.2', 1),
(9, 'asus', 'cabin104', '234.09', 1),
(10, 'asusbook', 'cabin2', '735.12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

DROP TABLE IF EXISTS `userdetails`;
CREATE TABLE IF NOT EXISTS `userdetails` (
  `TRN` int NOT NULL AUTO_INCREMENT,
  `Users_id` int NOT NULL,
  `InTime` timestamp NOT NULL,
  `TimeOUT` timestamp NOT NULL,
  `Amount` int NOT NULL,
  `Remarks` varchar(25) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`TRN`),
  KEY `idxUID` (`Users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `userdetails`
--

INSERT INTO `userdetails` (`TRN`, `Users_id`, `InTime`, `TimeOUT`, `Amount`, `Remarks`, `status`) VALUES
(20, 13, '2025-05-12 07:02:31', '2025-05-12 12:38:43', 20, '                 ok      ', 'Out'),
(21, 14, '2025-05-12 07:12:28', '0000-00-00 00:00:00', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `usermaster`
--

DROP TABLE IF EXISTS `usermaster`;
CREATE TABLE IF NOT EXISTS `usermaster` (
  `Users_id` int NOT NULL AUTO_INCREMENT,
  `ComputerName` varchar(100) NOT NULL,
  `EntryID` varchar(100) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `UserAddress` varchar(200) DEFAULT NULL,
  `Email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `MobileNumber` varchar(13) DEFAULT NULL,
  `IDProofType` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `IDProofNo` varchar(15) NOT NULL,
  PRIMARY KEY (`Users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `usermaster`
--

INSERT INTO `usermaster` (`Users_id`, `ComputerName`, `EntryID`, `UserName`, `UserAddress`, `Email`, `MobileNumber`, `IDProofType`, `IDProofNo`) VALUES
(13, 'HP', '698118448', 'Bhavya hegde', 'kalgadde sirsi \r\nuttarakannada', 'bhavya@gmail.com', '8765432567', 'Aadhar', '32142134 5678'),
(14, 'asus', '509079373', 'varsha ', 'yellapur\r\nuttarakannada', 'varsha@gmail.com', '6385432876', 'Voter ID', 'FQ3749259096');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `computerdetails`
--
ALTER TABLE `computerdetails`
  ADD CONSTRAINT `FKCompID2` FOREIGN KEY (`ComputerID`) REFERENCES `computers` (`ComputerID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
