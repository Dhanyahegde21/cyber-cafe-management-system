<?php
session_start();
include('connection.php');

if (strlen($_SESSION['ccmsaid']) == 0) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        $adminid = $_SESSION['ccmsaid'];  // Get the admin ID from the session
        $currentpassword = $_POST['currentpassword'];  // Get and hash the current password
        $newpassword = $_POST['newpassword'];  // Get and hash the new password

        // Check if the current password entered matches the one in the database
        $query = mysqli_query($conn, "SELECT AdminID, Passwd FROM admin WHERE AdminID='$adminid'");
        $row = mysqli_fetch_array($query);
     
        


    if ($row && password_verify($currentpassword, $row['Passwd'])) {
        $hashed_new_password = password_hash($newpassword, PASSWORD_DEFAULT);
        $update = mysqli_query($conn, "UPDATE admin SET Passwd='$hashed_new_password' WHERE AdminID='$adminid'");

        $msg = $update ? "Your password has been successfully changed." : "Something went wrong while updating the password.";
    } else {
        $msg = "Your current password is incorrect.";
    }
}

?>

<!doctype html>
<html class="no-js" lang="en">
<head>
    <title>CCMS Change Password</title>

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <script type="text/javascript">
    function checkpass() {
        if (document.changepassword.newpassword.value != document.changepassword.confirmpassword.value) {
            alert('New Password and Confirm Password field do not match');
            document.changepassword.confirmpassword.focus();
            return false;
        }
        return true;
    }
    </script>
</head>

<body>
    <?php include_once('sidebar.php');?>

    <div id="right-panel" class="right-panel">
        <?php include_once('header.php');?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Change Password</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="dashboard.php">Dashboard</a></li>
                            <li><a href="change-password.php">Change Password</a></li>
                            <li class="active">Change</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Change</strong><small> Password</small></div>
                            <form name="changepassword" method="post" onsubmit="return checkpass();" action="">
                                <p style="font-size:16px; color:red" align="center"></p>
                                <div class="card-body card-block">
                                    <div class="form-group">
                                        <label for="currentpassword" class="form-control-label">Current Password</label>
                                        <input type="password" name="currentpassword" id="currentpassword" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="newpassword" class="form-control-label">New Password</label>
                                        <input type="password" name="newpassword" id="newpassword" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="confirmpassword" class="form-control-label">Confirm Password</label>
                                        <input type="password" name="confirmpassword" id="confirmpassword" class="form-control" required>
                                    </div>
                                </div>
                                <div class="card-footer text-center">
                                    <button type="submit" class="btn btn-primary btn-sm" name="submit" id="submit">
                                        <i class="fa fa-dot-circle-o"></i> Change
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- .row -->
            </div> <!-- .animated -->
        </div> <!-- .content -->
    </div> <!-- /#right-panel -->

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
    <script src="vendors/jquery-validation-unobtrusive/dist/jquery.validate.unobtrusive.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>

<?php } ?>